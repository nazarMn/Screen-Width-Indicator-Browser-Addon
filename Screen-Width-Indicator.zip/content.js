let indicator = null;
let intervalId = null; // Для зберігання ID інтервалу
let timeoutId = null;  // Для зберігання ID таймера

// Час, протягом якого показується індикатор (в мілісекундах)
const DISPLAY_TIME = 12000; // 12 секунд

function showBrowserDimensions() {
  const browserWidth = window.innerWidth; // Точна ширина вікна браузера (без інтерфейсу)
  const browserHeight = window.innerHeight; // Точна висота вікна браузера (без інтерфейсу)

  if (!indicator) {
    // Створюємо індикатор, якщо його ще немає
    indicator = document.createElement('div');
    indicator.style.position = 'fixed';
    indicator.style.top = '10px';
    indicator.style.right = '10px';
    indicator.style.padding = '10px';
    indicator.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    indicator.style.color = 'white';
    indicator.style.fontSize = '16px';
    indicator.style.borderRadius = '5px';
    indicator.style.zIndex = '9999'; // Забезпечує, щоб індикатор був поверх інших елементів
    indicator.style.maxWidth = '200px'; // Максимальна ширина індикатора
    indicator.style.wordWrap = 'break-word'; // Переносить текст, якщо він не вміщується
    document.body.appendChild(indicator);
  }

  // Оновлюємо контент індикатора в реальному часі
  indicator.textContent = `Browser Width: ${browserWidth}px\nBrowser Height: ${browserHeight}px`;
}

function handleWheelEvent(event) {
  if (event.ctrlKey) { // Перевірка, чи натиснуто Ctrl
    if (indicator) {
      indicator.style.display = 'block'; // Показуємо індикатор при прокручуванні з Ctrl
    }

    // Оновлюємо дані кожні 500 мс
    if (!intervalId) {
      intervalId = setInterval(showBrowserDimensions, 500); // Оновлюємо розміри кожні 500 мс
    }

    // Якщо таймер вже існує, очищаємо його
    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    // Встановлюємо таймер на 12 секунд
    timeoutId = setTimeout(() => {
      clearInterval(intervalId); // Очищаємо інтервал після 15 секунд
      intervalId = null; // Обнуляємо ID інтервалу
      indicator.style.display = 'none'; // Ховаємо індикатор після 15 секунд
    }, DISPLAY_TIME); // 12000 мс = 12 секунд
  }
}

function handleKeyEvent(event) {
  // Перевіряємо, чи натиснуто Ctrl і або +, або -
  if (event.ctrlKey && (event.key === '+' || event.key === '-')) {
    if (indicator) {
      indicator.style.display = 'block'; // Показуємо індикатор при натисканні Ctrl + (+ або -)
    }

    // Оновлюємо дані кожні 500 мс
    if (!intervalId) {
      intervalId = setInterval(showBrowserDimensions, 500); // Оновлюємо розміри кожні 500 мс
    }

    // Якщо таймер вже існує, очищаємо його
    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    // Встановлюємо таймер на 12 секунд
    timeoutId = setTimeout(() => {
      clearInterval(intervalId); // Очищаємо інтервал після 12 секунд
      intervalId = null; // Обнуляємо ID інтервалу
      indicator.style.display = 'none'; // Ховаємо індикатор після 12 секунд
    }, DISPLAY_TIME); // 12000 мс = 12 секунд
  }
}

function handleStopWheelEvent(event) {
  if (event.ctrlKey && indicator) {
    // Якщо прокручування припиняється, ми очищаємо таймер і зупиняємо оновлення
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      clearInterval(intervalId); // Очищаємо інтервал після 12 секунд без прокручування
      intervalId = null; // Обнуляємо ID інтервалу
      indicator.style.display = 'none'; // Ховаємо індикатор після 12 секунд
    }, 12000); // Ховати через 12 секунду після припинення прокручування
  }
}

// Додаємо слухачів подій
window.addEventListener('wheel', handleWheelEvent);
window.addEventListener('wheel', handleStopWheelEvent);
window.addEventListener('keydown', handleKeyEvent); // Додаємо слухач для натискання клавіш
