// popup.js
document.addEventListener('DOMContentLoaded', function () {
    const widthElement = document.getElementById('width');
  
    // Функція для оновлення ширини екрана
    function updateWidth() {
      const screenWidth = window.innerWidth;
      widthElement.textContent = `Width: ${screenWidth}px`;
    }
  
    // Оновлюємо ширину екрана при завантаженні
    updateWidth();
  
    // Слухаємо зміни розміру вікна
    window.addEventListener('resize', updateWidth);
  });
  